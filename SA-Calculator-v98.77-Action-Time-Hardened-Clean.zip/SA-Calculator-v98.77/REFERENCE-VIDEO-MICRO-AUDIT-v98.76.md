# SA Calculator v98.76 — Reference Video Micro Audit

Basis: the eight supplied 720×1560 screen recordings uploaded on 2026-11-23.

## Rebuilt surfaces

- Currency Converter: compact Dollar/Rupee paired cards, USD→INR default, blank source amount, compact code selector, live conversion, rate note only, no visible refresh/status/extra From/To headings, currency picker without search, selected currency pinned first.
- GST Calculator: Original Amount + GST mode + GST Rate + rate pills + Same/Different State, no visible Calculate button, equals key commits the result.
- Loan Calculator: Loan Amount + Interest Rate + Loan Tenure, native tenure wheel, equals commits result, result rows match the recording structure.
- Discount Calculator: Original Price + Discount Rate only before equals; result block reveals Original Amount, Discount Rate, Discount Amount, Amount You Save and Final Price.
- Unit Converter: horizontal category chips, Weight default, direct two-card workspace, Unit List picker without search, swap action on tall keypad key, added Current and Voltage, video-matched defaults for Weight/Time/Volume/Data/Current/Voltage.
- Age Calculator: date fields + in-screen Calculate button, no automatic numeric keypad, date picker flow retained, result card reveals after Calculate.
- BMI Calculator: Weight + Height cards, kg/lbs and cm/in pills, three-digit entry guard, equals commits result, invalid input remains controlled.

## Action-time hardening

- Shared keypad uses a fixed 4×4 touch-safe grid.
- Currency and Unit tall action key is swap, not calculate.
- Numeric tool result state is invalidated as soon as an input is edited.
- Android/system Back dismisses the keypad before leaving a tool.
- Tool Back returns to the exact parent surface.
- Select pickers close the keypad before opening and restore focus safely.
- No tool screen auto-opens the numeric dock for Age Calculator.
- Root and generated `www/` JavaScript/CSS/HTML are byte-identical after web preparation.
- Service-worker cache namespace is bumped to v98.76 so stale v98.75 assets are not intentionally reused.

## Validation

- `node --check` passes for release JavaScript files.
- Release regression suite: 70/70 PASS.
- Web bundle preparation: PASS.
- Root/`www` synchronization: PASS.
- Workflow source identity checks are synchronized to v98.76 / Android versionCode 1098601.

Physical Android handset touch/FPS validation is not available in this build environment.
